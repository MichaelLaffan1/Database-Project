--Get the number of copies sold and genres of all video games, 
--along with the rating scores they received and the ids of the reviewers that rated them, if any.
CREATE OR REPLACE VIEW XQUERY5 AS
SELECT DISTINCT R.REVIEWER_ID, R.RATE_SCORE, G.GAME_COPIES, G.GAME_GENRE
FROM XRATES R RIGHT JOIN XGAMES G ON
R.GAME_ID = G.GAME_ID;
