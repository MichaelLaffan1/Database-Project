--Get the ids of cast members that are cast in none of the games with a price greater than 39.99.
CREATE OR REPLACE VIEW XQUERY3 AS
SELECT C.CAST_ID
FROM XCASTMEMBERS C
WHERE C.CAST_ID IN
    (SELECT CA.CAST_ID
     FROM XCASTS CA
     WHERE CA.GAME_ID NOT IN
        (SELECT G.GAME_ID
         FROM XGAMES G
         WHERE G.GAME_PRICE > 39.99));
