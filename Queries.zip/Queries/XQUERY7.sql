--Get the names of reviewers along with the rating scores of games 
--that were given a score of less than 8 and created by a developer 
--owned by a publisher located in Santa Monica.
CREATE OR REPLACE VIEW XQUERY7 AS
SELECT DISTINCT R.REVIEWER_NAME, RA.RATE_SCORE
FROM XREVIEWERS R, XRATES RA, XGAMES G, XDEVELOPS DV, XDEVELOPERS D, XPUBLISHERS P
WHERE R.REVIEWER_ID = RA.REVIEWER_ID
AND RA.GAME_ID = G.GAME_ID
AND G.GAME_ID = DV.GAME_ID
AND DV.DEVELOPER_ID = D.DEVELOPER_ID
AND D.PUBLISHER_ID = P.PUBLISHER_ID
AND RA.RATE_SCORE < 8
AND P.PUBLISHER_LOCATION = 'Santa Monica';
