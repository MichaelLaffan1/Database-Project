--Get the names and ages of all cast members along with the names and prices of 
--video games they were cast in, if any, and include names and prices of all video 
--games along with the names and ages of the cast members they cast, if any.
CREATE OR REPLACE VIEW XQUERY6 AS
SELECT C.CAST_NAME, C.CAST_AGE, G.GAME_NAME, G.GAME_PRICE
FROM XCASTMEMBERS C FULL JOIN XCASTS CA ON
C.CAST_ID = CA.CAST_ID FULL JOIN XGAMES G ON
CA.GAME_ID = G.GAME_ID;
