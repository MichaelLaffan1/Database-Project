--Get the ids of games that can be played on every platform.
CREATE OR REPLACE VIEW XQUERY1 AS
SELECT G.GAME_ID 
FROM XGAMES G
WHERE NOT EXISTS
    (SELECT P.*
     FROM XPLATFORMS P
     WHERE NOT EXISTS
        (SELECT PL.*
         FROM XPLAYS PL
         WHERE G.GAME_ID = PL.GAME_ID
         AND PL.PLATFORM_ID = P.PLATFORM_ID));
