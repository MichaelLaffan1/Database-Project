--Get the ids of developers that only develop 'Action-Adventure' games.
CREATE OR REPLACE VIEW XQUERY2 AS
SELECT D.DEVELOPER_ID
FROM XDEVELOPERS D
WHERE D.DEVELOPER_ID NOT IN
    (SELECT DV.DEVELOPER_ID
     FROM XDEVELOPS DV
     WHERE DV.GAME_ID NOT IN
        (SELECT G.GAME_ID
         FROM XGAMES G
         WHERE G.GAME_GENRE = 'Action-Adventure'));
