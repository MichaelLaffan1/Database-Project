--Get the names and locations of all publishers, along with the names and 
--headquarters of the developers they own, if any.
CREATE OR REPLACE VIEW XQUERY4 AS
SELECT P.PUBLISHER_NAME, P.PUBLISHER_LOCATION, D.DEVELOPER_NAME, D.DEVELOPER_HQ
FROM XPUBLISHERS P LEFT JOIN XDEVELOPERS D ON
P.PUBLISHER_ID = D.PUBLISHER_ID;
